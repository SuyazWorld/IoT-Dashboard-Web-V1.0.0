<?php
// API tidak perlu di-include ke index.php atau file utama, berbeda dengan halaman lain seperti dashboard.php yang harus di-include.
// File API (api.php) → Bertugas menerima dan memproses request dari ESP32/webhook dan menyimpan data ke database. API tidak menampilkan halaman HTML.
// File halaman web (index.php, dashboard.php) → Bertugas menampilkan data kepada user (manusia), misalnya tampilan tabel sensor di dashboard.

include "../config/database.php";
$data_loggingets =  json_decode(file_get_contents('php://input'), true); //untuk memecah
$topiczxz = $data_loggingets['topic'];
$paylopadzxz = $data_loggingets['payload'];

$topic_explode = explode("/", $topiczxz);
$sernum_sensordat = $topic_explode[1];
$data_name = $topic_explode[2];

if($topiczxz == "kelasiot/ESP32-01/ultras" || $topiczxz == "kelasiot/ESP32-01/pot1" || $topiczxz == "kelasiot/ESP32-01/pot2"){
    if($topic_explode[2] == "ultras"){
        $sensortype = "Ultras"; //sesuaikan dengan di database, soalnya SensorType itu enum
    }else if ($topic_explode[2] == "pot1"){
        $sensortype = "Poten1";
    }else if($topic_explode[2] == "pot2"){
        $sensortype = "Poten2";
    }
    //insert data ultras dulu, tapi query ini hanya akan berjalan jika device sudah terdaftar di
    $sql_insertultrasz = "INSERT INTO data_sensors (serialnum_device, SensorType, data_value, data_namez, mqtt_topic_pot)
                        VALUES('$sernum_sensordat','$sensortype','$paylopadzxz', '$data_name','$topiczxz')";
    mysqli_query($db_connection,$sql_insertultrasz);
}
if($topiczxz == "kelasiot/ESP32-01/led1" || $topiczxz == "kelasiot/ESP32-01/led2" || $topiczxz == "kelasiot/ESP32-01/servoxxx" || $topiczxz == "kelasiot/ESP32-01/srvvzz"){
    if($topic_explode[2] == "led1"){
        $actuatortype = "LED1"; //sesuaikan dengan di database, soalnya SensorType itu enum
    }else if ($topic_explode[2] == "led2"){
        $actuatortype = "LED2";
    }else if($topic_explode[2] == "servoxxx"){
        $actuatortype = "Servo1";
    }else if($topic_explode[2] == "srvvzz"){
        $actuatortype = "Servo2";
    }
    //insert data ultras dulu, tapi query ini hanya akan berjalan jika device sudah terdaftar di
    $sql_insert_act = "INSERT INTO data_actuator (serialnum_device, actuatortype, data_value, data_name, mqtt_topics)
                        VALUES('$sernum_sensordat','$actuatortype','$paylopadzxz', '$data_name','$topiczxz')";
    mysqli_query($db_connection,$sql_insert_act);
}
?>
<?php
$serverhostname = 'localhost';
$usernamephpmyadmin = 'root';
$passphpmyadmin = '';
$databseyangdipakai = 'kelasiot_nocomment';
$db_connection = mysqli_connect($serverhostname, $usernamephpmyadmin, $passphpmyadmin, $databseyangdipakai);
// Cek koneksi
if(!$db_connection) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>
  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Version V.1.3.0
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; Aryzz IoT <a href="https://google.co.id">Aryzz.io</a>.</strong> All rights reserved.
  </footer>
</div>
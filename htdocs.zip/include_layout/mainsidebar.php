<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: #1B4332;">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="dist/img/ssaaa.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">ARYZZ IOT V1</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <!-- <div class="image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div> -->
        <div class="info">
          <a class="d-block"><?php echo $_SESSION['fullname_sessionz'];?> (<?php echo $_SESSION['role_sessionz']; ?>)</a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      <!-- <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div> -->

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- nav menu Dashboard -->
          <li class="nav-item">
            <!-- href / itu artinya langsung ke index.php -->
            <a href="/" class="nav-link">
              <i class="nav-icon fas bi-columns-gap"></i>
              <p>
                Dashboard
                <!-- <span class="right badge badge-danger">New</span> -->
              </p>
            </a>
          </li>
          <!-- nav menu data sensor -->
          <li class="nav-item">
            <a href="?page=sensordata" class="nav-link">
              <i class="nav-icon fas bi-thermometer-sun"></i>
              <p>
                Sensor Data
                <!-- <span class="right badge badge-danger">New</span> -->
              </p>
            </a>
          </li>
          <!-- nav menu Chart -->
          <li class="nav-item">
            <a href="?page=ultraschart" class="nav-link">
              <i class="nav-icon fas fa-chart-bar"></i>
              <p>
                Sensor Chart
                <!-- <span class="right badge badge-danger">New</span> -->
              </p>
            </a>
          </li>
          <!-- nav menu aktuator -->
          <li class="nav-item">
            <a href="?page=actuatordata" class="nav-link">
              <i class="nav-icon fas bi-speedometer"></i>
              <p>
                Actuator Data
                <!-- <span class="right badge badge-danger">New</span> -->
              </p>
            </a>
          </li>
          <!-- nav menu devices -->
          <li class="nav-item">
            <a href="?page=devicedata" class="nav-link">
              <i class="nav-icon fas bi-cpu"></i>
              <p>
                Devices
                <!-- <span class="right badge badge-danger">New</span> -->
              </p>
            </a>
          </li>
          <?php if($_SESSION['role_sessionz'] == "Admin"){?>
          <!-- nav menu User -->
          <li class="nav-item">
            <a href="?page=userdata" class="nav-link">
              <i class="nav-icon fas bi-person-circle"></i>
              <p>
                User
                <!-- <span class="right badge badge-danger">New</span> -->
              </p>
            </a>
          </li>
          <?php }?>
          <!-- nav menu logout -->
          <li class="nav-item">
            <a href="logout.php" class="nav-link">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
                Logout
                <!-- <span class="right badge badge-danger">New</span> -->
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
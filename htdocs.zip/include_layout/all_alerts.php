<?php
function alertsukses($pesansukses){
    echo '
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-check"></i> Alert!</h5>'
        . $pesansukses  .
    '</div>';
}
function alertwarningz($pesanwarning){
    echo '
    <div class="alert alert-warning alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-exclamation-triangle"></i> Alert!</h5>'
        . $pesanwarning .
    '</div>';
}
function alertinfoz($pesaninfo){
    echo '
    <div class="alert alert-info alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-info"></i> Alert!</h5>'
        . $pesaninfo .
    '</div>';
}
function alertdanger($pesandangerz){
    echo '
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-ban"></i> Alert!</h5>'
        . $pesandangerz .
    '</div>';
}
?>
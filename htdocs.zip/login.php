<?php
  session_start();
  include "config/database.php"; //include database
  $notifloginz = "Input Username and Password Here!!";
  if(isset($_POST['usernameloginz'])){ //disini kenapa kita pakai usernameloginz bukan buttonloginz, karena ada kemungkinan user itu langsung pencet enter bukan tombol loginnya, makayna kita pakai usernameloginz aja
    $userloginphp = $_POST['usernameloginz'];
    $passloginphp = $_POST['passloginz'];

    $sql_cekusername = "SELECT * FROM data_orang WHERE usernamezz = '$userloginphp' LIMIT 1";
    $result_sqlcekusername  = $db_connection->query($sql_cekusername);
    // password_verify ini fungsi php untuk verify hash pass, tapi kita fecth assoc dulu dibawah
    $cekpass_hash = $result_sqlcekusername->fetch_assoc();


    if($result_sqlcekusername->num_rows>0){
      // berikut password verify
      if(password_verify($passloginphp, $cekpass_hash['passwordz2'])){
        $_SESSION['username_sessionz'] = $userloginphp;
        $_SESSION['fullname_sessionz'] = $cekpass_hash['fullname']; //disini kita bisa pakai variabel $cekpass_hash buat ambil data fullname
        $_SESSION['role_sessionz'] = $cekpass_hash['peran'];

        echo "<script>location.href='index.php'</script>"; //ini kita pakai redirect ke page lain, tapi disini kita pakai javascript, pakai header php juga bisa sih harusnya
        // bisa juga: header("Location: index.php");
      }else{
        $notifloginz = "<b style='color:red'>Password salah!!</b>";
      }
    }else{
      $notifloginz = "<b style='color:yellow'>Username tidak terdaftar!!</b>";
    }
    $db_connection->close();
  }
  // contoh pass verify dibawah
  // $hash = '$2y$12$4Umg0rCJwMswRw/l.SwHvuQV01coP0eWmGzd61QH2RvAOMANUBGC.';
  // if (password_verify('rasmuslerdorf', $hash)) {
  //     echo 'Password is valid!';
  // } else {
  //     echo 'Invalid password.';
  // }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Aryzz IoT V1.0.0</title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page" style="background-color:#1b4332;">
<div class="login-box">
  <div class="login-logo">
    <span style="color:white;"><b>ARYZZ</b> IoT V1.0.0</span>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg"><?php echo $notifloginz?></p>
      <!-- action="/" Ini berarti formulir akan mengirim data ke halaman utama (root) dari domain. -->
      <!-- action="" (kosong) Ini berarti formulir akan mengirim data ke halaman yang sama dengan tempat form itu berada. -->
      <!-- bisa juga action="login.php" , kita taruh halaman itu sendiri disini, cuma bakal ada sedikit perbedaan -->
      <form action="" method="POST">
        <div class="input-group mb-3">
          <input type="text" class="form-control" name="usernameloginz" placeholder="Input Username here" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" name="passloginz" placeholder="Input Password here" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <button type="submit" name="buttonlogin" class="btn btn-success btn-block">Sign In</button>
          </div>
        </div>
      </form>
      
      <!-- <p class="mb-1">
        <a href="forgot-password.html">I forgot my password</a>
      </p>
      <p class="mb-0">
        <a href="register.html" class="text-center">Register a new membership</a>
      </p> -->
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>

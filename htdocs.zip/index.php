<?php 
  session_start();
  include "config/database.php"; //include database
  if(empty($_SESSION['username_sessionz'])){
    header("Location: login.php");
    exit();
  }
  // bisa juga:
  // if(!isset($_SESSION['username_sessionz'])){
  //   header("Location: login.php");
  //   exit();
  // }
  // isset() hanya mengecek apakah variabel ada atau tidak. Jika $_SESSION['username_sessionz'] ada tetapi kosong ("" atau null), isset() tetap akan mengembalikan true, sehingga user tetap bisa masuk.

  include "include_layout/header.php";
  include "include_layout/navbar.php";
  include "include_layout/mainsidebar.php";
  include "include_layout/all_alerts.php";
// <!-- Content Wrapper. Contains page content -->
if(isset($_GET['page'])){
  $halamanterbuka = $_GET['page']; //page di dalam ['page'] itu mengarah ke halaman itu sendiri bukan ke suatu id atau name element html, nanti ini di dapat dari mainsidebar.php, dari hrefnya
  include "mainpages/". $halamanterbuka . ".php";
} else{
  include "mainpages/dashboard.php";
};

// <!-- Main Footer -->
include "include_layout/footer.php";
?>


<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- jangan lupa input jquery (javascript query) data tables dan plugin DAN JUGA JANGAN LUPA INPUT CSS datatablesnya dibagian atas di file header-->
<!-- jangan lupa ubah lokasi foldernya -->
<!-- DataTables  & Plugins -->
 
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- Ion Slider -->
<script src="plugins/ion-rangeslider/js/ion.rangeSlider.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

</body>



<!-- Page specific script, ini script buat datatables -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  });
  $(function () {
    $("#tablepot1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#tablepot1_wrapper .col-md-6:eq(0)');
  });
  $(function () {
    $("#tablepot2").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#tablepot2_wrapper .col-md-6:eq(0)');
  });
</script>
<!-- ini buat sliders  -->
<script>
  $(function () {
    /* ION SLIDER */
    $('#servo1').ionRangeSlider({
      min     : 0,
      max     : 180,
      from    : 0,
      type    : 'single',
      step    : 1,
      postfix : '°',
      prettify: false,
      hasGrid : true
    })
    $('#servo2').ionRangeSlider({
      min     : 0,
      max     : 180,
      from    : 0,
      type    : 'single',
      step    : 1,
      postfix : '°',
      prettify: false,
      hasGrid : true
    })
  })
</script>
</html>

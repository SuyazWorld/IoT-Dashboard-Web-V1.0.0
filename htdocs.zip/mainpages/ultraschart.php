<?php
// Query untuk mengambil data
$sql_ambildatachart = "SELECT * FROM data_sensors";
$result_showchart = $db_connection->query($sql_ambildatachart);

// Menyimpan hasil query ke dalam array
$labels_datainTime = [];
$datachart_ultras = [];
$datachart_pot1 = [];
$datachart_pot2 = [];

while ($row_sensorchart = $result_showchart->fetch_assoc()) {
    $labels_datainTime[] = $row_sensorchart['DataIn_Time'];  // Sesuaikan dengan nama kolom waktu
    if ($row_sensorchart['SensorType'] == "Ultras") {
        $datachart_ultras[] = $row_sensorchart['data_value'];
    } elseif ($row_sensorchart['SensorType'] == "Poten1") {
        $datachart_pot1[] = $row_sensorchart['data_value'];
    } elseif ($row_sensorchart['SensorType'] == "Poten2") {
        $datachart_pot2[] = $row_sensorchart['data_value'];
    }
}

// Ubah array PHP menjadi format JSON agar bisa digunakan di JavaScript
$labels_datainTime_json = json_encode($labels_datainTime);
$dataUltras_json = json_encode($datachart_ultras);
$dataPot1_json = json_encode($datachart_pot1);
$dataPot2_json = json_encode($datachart_pot2);
?>

<!-- Content Wrapper -->
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Sensor Data History</h1>
        </div>
      </div>
    </div>
  </div>

  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Sensor Chart</h3>
            </div>
            <div class="card-body">
              <div class="col-12">
                <canvas id="myChart" style="width: 100% !important; height: 400px !important;"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  // Ambil data dari PHP dan konversi menjadi format yang dapat digunakan di Chart.js
  const labels_datainTime_C = <?php echo $labels_datainTime_json; ?>;
  const data_ultrasC = <?php echo $dataUltras_json; ?>;
  const data_pot1C = <?php echo $dataPot1_json; ?>;
  const data_pot2C = <?php echo $dataPot2_json; ?>;

  new Chart("myChart", {
    type: "line",
    data: {
      labels: labels_datainTime_C,
      datasets: [{
        label: "Ultras (Red)",
        data: data_ultrasC,
        borderColor: "red",
        backgroundColor: "rgba(255, 0, 0, 0.1)",
        fill: true
      },{
        label: "Potentio 1 (Blue)",
        data: data_pot1C,
        borderColor: "blue",
        backgroundColor: "rgba(0, 0, 255, 0.1)",
        fill: true
      },{
        label: "Potentio 2 (Green)",
        data: data_pot2C,
        borderColor: "green",
        backgroundColor: "rgba(0, 255, 0, 0.1)",
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: "top",
          labels: {
            color: "black",
            font: {
              size: 14
            }
          }
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            text: "Waktu (DataIn_Time)",
            color: "black",
            font: {
              size: 14,
              weight: "bold"
            }
          },
          ticks: {
            autoSkip: true,
            maxTicksLimit: 10, // Batasi jumlah label di sumbu X agar tetap rapi
            color: "black"
          }
        },
        y: {
          title: {
            display: true,
            text: "Nilai Sensor",
            color: "black",
            font: {
              size: 14,
              weight: "bold"
            }
          },
          ticks: {
            color: "black"
          }
        }
      }
    }
  });
</script>

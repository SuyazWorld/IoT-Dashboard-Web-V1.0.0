<?php
$currentpageedit = $_GET['page'];
$alert_insertnotif = (int) 0;

//edit data
if(isset($_POST['edit_hidden'])){
  $old_sernum = $_POST['edit_hidden'];
  $serialnum_edit = $_POST['serialnum_edit'];
  $controllertype_edit = $_POST['controller_edit'];
  $location_edit = $_POST['location_edit'];
  $kondition_edit = $_POST['condition_edit'];
  $sql_editdata = "UPDATE data_devices SET serialnum_device = '$serialnum_edit', micro_controllertipe='$controllertype_edit', device_location='$location_edit', conditionz='$kondition_edit' WHERE serialnum_device='$old_sernum'";
  $result_sqledit = $db_connection->query($sql_editdata);
  if ($result_sqledit) {
    $alert_insertnotif = (int) 1;
  }else{
    $alert_insertnotif = (int) 2;
  }
}
// tmbah data
elseif(isset($_POST['insernewdevicebtn'])){
  $serialnumnew = $_POST['serialnum_new'];
  $controllertypenew = $_POST['controller_new'];
  $locationnew = $_POST['location_new'];
  $sql_newinsertdevice = "INSERT INTO data_devices (serialnum_device, micro_controllertipe, device_location) VALUES ('$serialnumnew', '$controllertypenew', '$locationnew')";
  $result_sqlnewinsertdata = $db_connection->query($sql_newinsertdevice);
  if ($result_sqlnewinsertdata) {
    $alert_insertnotif = (int) 3;
  }else{
    $alert_insertnotif = (int) 4;
  }
}
// menampilkan data di tabel edit data
if(isset($_GET['editdataz'])){
  $serialnumbedit_get = $_GET['editdataz'];
  $sql_editdevicedata = "SELECT * FROM data_devices WHERE serialnum_device = '$serialnumbedit_get' LIMIT 1"; //sebelum edit data, kita buat dulu query select dulu untuk memilih data mana yang mau diedit
  // terus limit itu buat munculin satu data saja yang udah dipilihi, jadi jika udah nemu satu data , maka sql akan berhenti mencari lagi
  $result_editselect = $db_connection->query($sql_editdevicedata);
  $rowdevice_edit = $result_editselect->fetch_assoc();
}


$sql_showdevicedata =  "SELECT * FROM data_devices"; //data_devices itu nama data total di database, bukan nama kolom,nanti kalo ada WHERE nya baru nama kolom
$result_sqlshowdevicedata = $db_connection->query($sql_showdevicedata);
//mirip $result_sqlshowdevicedata = mysqli_query($db_connection, $sql_showdevicedata)//



?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Devices</h1>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <!-- Main content -->
  <div class="content">
    <div class="container-fluid">
      <div class="row">
      <!-- kalo lg- 6 div nya cuma setengah layar. kalo 12 dia full layar -->
        <div class="col-lg-12">
          <?php
            if ($alert_insertnotif == (int) 3) {alertsukses("Data berhasil ditambahkan....");}
            elseif ($alert_insertnotif == (int) 4) {alertdanger("Data GAGAL ditambahkan....");}
            elseif ($alert_insertnotif == (int) 1) {alertsukses("Data berhasil diEDIT....!!!");}
            elseif ($alert_insertnotif == (int) 2) {alertdanger("Data GAGAL diEDIT....!!!");}
          ?>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Devices List</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Device Num</th>
                  <th>Type</th>
                  <th>location</th>
                  <th>RegisterTime</th>
                  <th>Condition</th>
                  <th>Edit Data</th>
                </tr>
                </thead>
                <tbody>
                  <?php while($row_device = $result_sqlshowdevicedata->fetch_assoc()){?>
                    <tr>
                    
                      <td><?php echo $row_device["serialnum_device"]; ?></td>
                      <td><?php echo $row_device["micro_controllertipe"]; ?></td>
                      <td><?php echo $row_device["device_location"]; ?></td>
                      <td> <?php echo $row_device["registered_time"]; ?></td>
                      <td><?php echo $row_device["conditionz"]; ?></td>
                      <td><a href="?page=<?php echo $currentpageedit?>&editdataz=<?php echo $row_device['serialnum_device']?>"><i class="fas fa-edit"></i></a></td>
                      <!-- kita kasi tag a sebelum tag i biar logonya bisa dipencet -->
                      <!-- <a href="?page=devicedata&edit= ?php echo $row_device['serialnum_device'] ?>" artinya method get ini ada dua parameter yaitu page dan editdataz  -->
                      <!-- $page = $_GET['page']; // "devicedata"
                          $edit = $_GET['edit']; // "serialnum_device"-->
                      <!-- parameter page itu dipakein variabel php, biar gampang kita pakai fungsi edit ini di page lain misalnya user -->
                      <!-- parameter edit nanti akan digunakan di method get if else untuk edit form dibawah -->
                    </tr>
                  <?php }?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
        <!-- form tambah dan edit data -->
        <?php if(isset($_GET['editdataz'])){?>
          <!-- form edit data -->
          <div class="col-md-12">
            <div class="card card-orange">
              <div class="card-header">
                <h3 class="card-title">Edit Data</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="?page=devicedata" method="POST">
                <!-- action itu dikirim ke page yang ada php untuk mengatur insert datanya, kita kirim ke sini karena phpnya ada diatas -->
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Serial Number</label>
                    <!-- kalo input hidden ini buat method get untuk insert data, typenya hidden biar ini ga kliatan, ini cuma buat pancingan method getnya aja -->
                    <!-- ketika ada atribut name="edit_hidden" yang diPOST, maka nanti kita akan jalan query buat edit data atau query UPDATE, beginilah yang kita maksud untuk pancingan ke query update data -->
                    <!-- input hidden ini dikasi value juga bukan untuk mengedit data tapi untuk memilih data mana yang akan diedit atau diupdate -->
                    <input type="hidden" name="edit_hidden" value="<?php echo $rowdevice_edit['serialnum_device']?>">
                    <input type="text" class="form-control" name="serialnum_edit" value="<?php echo $rowdevice_edit['serialnum_device']?>" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Controller Type</label>
                    <input type="text" class="form-control" name="controller_edit" id="exampleInputPassword1" value="<?php echo $rowdevice_edit['micro_controllertipe'] ?>" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Location</label>
                    <input type="text" class="form-control" name="location_edit" id="exampleInputPassword1" value="<?php echo $rowdevice_edit['device_location'] ?>" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Status</label>
                    <select class="form-control" name="condition_edit">
                      <?php if($rowdevice_edit['conditionz']=="Active"){ ?>
                        <option value="Active">Active</option>
                        <option value="Not-Active">Not-Active</option>
                      <?php } else{?>
                        <option value="Not-Active">Not-Active</option>
                        <option value="Active">Active</option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" name="editdevicebtn" class="btn btn-warning">Edit</button>
                </div>
              </form>
            </div>
          </div>
        <?php } else { ?>
          <!-- form tambah data-->
          <div class="col-md-12">
            <div class="card card-olive">
              <div class="card-header">
                <h3 class="card-title">New Device</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="?page=devicedata" method="POST">
                <!-- action itu dikirim ke page yang ada php untuk mengatur insert datanya, kita kirim ke sini karena phpnya ada diatas -->
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Serial Number</label>
                    <!-- required itu atribut buat input, jadi kalo blm diisi udah dipencet tombol submit nanti pasti ada peringatan buat isi -->
                    <input type="text" class="form-control" name="serialnum_new" placeholder="Serial number must be different" required> 
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Controller Type</label>
                    <input type="text" class="form-control" name="controller_new" id="exampleInputPassword1" placeholder="Controller Type" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Location</label>
                    <input type="text" class="form-control" name="location_new" id="exampleInputPassword1" placeholder="Location" required>
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" name="insernewdevicebtn" class="btn btn-success">Add</button>
                </div>
              </form>
            </div>
          </div>
        <?php }?>
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<!-- NOTE video 131: -->
<!-- 1. setelah input card tables, jangan lupa input jquery atau javascript  di data.hml, lalu ditaruh dibagian paling bawah index.php, ditaruh stelah bootsrap 4 jangan lupa benerin lokasi foldernya -->
<!-- 2 setelah itu, jangan lupa input cssnya di data.hmtl, yaitu yang <!-- DataTables -> , nanti dipaste di header.php tepat dibawah  <!-- Font Awesome -> DAN JUGA JANGAN LUPA UBAH lokasinya-->
<!-- 3 terakhir copy yang javascript function di data.hml paling bawah, kalo table 1 itu idnya example 1 kalo table 2 idnya example 2, tapi disini kita pakai yang example2, nanti bisa dipaste di index.php, ditaruh paling bawah aja -->

<!-- VIDEO NOTE 132 -->
<!-- 1. include dulu database.php disini -->
<!-- 2. buat query dan printah untuk jalanin querynya -->
<!-- 3. pakai perulangan while untuk menampilkan data, makanya nanti elemen tr diatas kita masukin ke line php (nanti dijepit dua php) -->
 
<!-- note video 134, mirip dengan 133, tapi inget kasi ini ?page=devicedata di href di mainsidebar.php   -->
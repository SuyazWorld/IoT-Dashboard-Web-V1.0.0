<?php 
$sql_activedvicedash =  "SELECT * FROM data_devices WHERE conditionz = 'Active'";
$result_shwoactivedash = $db_connection->query($sql_activedvicedash);

// Query untuk mengambil data
$sql_ambildatachart = "SELECT * FROM data_sensors";
$result_showchart = $db_connection->query($sql_ambildatachart);

// Menyimpan hasil query ke dalam array
$labels_datainTime = [];
$datachart_ultras = [];
$datachart_pot1 = [];
$datachart_pot2 = [];

while ($row_sensorchart = $result_showchart->fetch_assoc()) {
    $labels_datainTime[] = $row_sensorchart['DataIn_Time'];  // Sesuaikan dengan nama kolom waktu
    if ($row_sensorchart['SensorType'] == "Ultras") {
        $datachart_ultras[] = $row_sensorchart['data_value'];
    } elseif ($row_sensorchart['SensorType'] == "Poten1") {
        $datachart_pot1[] = $row_sensorchart['data_value'];
    } elseif ($row_sensorchart['SensorType'] == "Poten2") {
        $datachart_pot2[] = $row_sensorchart['data_value'];
    }
}

// Ubah array PHP menjadi format JSON agar bisa digunakan di JavaScript
$labels_datainTime_json = json_encode($labels_datainTime);
$dataUltras_json = json_encode($datachart_ultras);
$dataPot1_json = json_encode($datachart_pot1);
$dataPot2_json = json_encode($datachart_pot2);
?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- ultras -->
          <div class="col-lg-4 col-4">
            <!-- small card -->
            <div class="small-box bg-purple">
              <div class="inner">
                <p>Ultras</p>
                <h3 id="ultras">???</h3>
              </div>
              <div class="icon">
                <i class="fas fa-people-arrows"></i>
              </div>
            </div>
          </div>
          <!-- pot1 -->
          <div class="col-lg-4 col-4">
            <!-- small card -->
            <div class="small-box bg-primary">
              <div class="inner">
                <p>Potentio 1</p>
                <h3 id="poten1">???</h3>
              </div>
              <div class="icon">
                <i class="fas fa-cog"></i>
              </div>
            </div>
          </div>
          <!-- pot2 -->
          <div class="col-lg-4 col-4">
            <!-- small card -->
            <div class="small-box bg-maroon">
              <div class="inner">
              <p>Potentio 2</p>
              <h3 id="poten2">???</h3>
              </div>
              <div class="icon">
                <i class="fas fa-life-ring"></i>
              </div>
            </div>
          </div>
          <!-- slider 1 / Servo 1 -->
          <div class="col-3">
            <div class="card card-pink">
              <div class="card-header">
                <h3 class="card-title">Servo 1</h3>
              </div>
              <div class="card-body">
                <div class="row margin">
                  <div class="col-sm-12">
                    <!-- berikut contoh atribut onchange -->
                    <input id="servo1" type="text" value="" onchange="publish_servo('servo1','kelasiot/ESP32-01/servoxxx')">
                  </div>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- slider 2 / Servo 2 -->
          <div class="col-3">
            <div class="card card-fuchsia">
              <div class="card-header">
                <h3 class="card-title">Servo 2</h3>
              </div>
              <div class="card-body">
                <div class="row margin">
                  <div class="col-sm-12">
                    <input id="servo2" type="text" value="" onchange="publish_servo('servo2','kelasiot/ESP32-01/srvvzz')">
                  </div>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- button 1 -->
          <div class="col-3">
            <div class="card card-indigo">
              <div class="card-header">
                <h3 class="card-title">LED 1</h3>
              </div>
              <div class="card-body table-responsive pad">
                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                  <label class="btn bg-primary" id="label-led1-on">
                    <input type="radio" name="options_led1" id="led1_ON" autocomplete="off"> ON
                  </label>
                  <label class="btn bg-primary" id="label-led1-off">
                    <input type="radio" name="options_led1" id="led1_OFF" autocomplete="off"> OFF
                  </label>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- button 2 -->
          <div class="col-3">
            <div class="card card-lime">
              <div class="card-header">
                <h3 class="card-title">LED 2</h3>
              </div>
              <div class="card-body table-responsive pad">
                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                  <label class="btn bg-info" id="label-led2-on">
                    <!-- ini bisa kita pakai onchange juga cuma lebih enak pakai addeventlistener -->
                    <!--<input type="radio" name="options_led2" id="led2_ON" autocomplete="off" onchange="publishlampu(this)"> ON  -->
                    <input type="radio" name="options_led2" id="led2_ON" autocomplete="off"> ON
                  </label>
                  <label class="btn bg-info" id="label-led2-off">
                    <input type="radio" name="options_led2" id="led2_OFF" autocomplete="off"> OFF
                  </label>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- table data device -->
          <div class="col-6 ">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Device Status List</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                  <thead>
                    <tr>
                      <th>Serial Number</th>
                      <th>Location</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while($row_dashactive = $result_shwoactivedash->fetch_assoc()){?>
                    <tr>
                      <td><?php echo $row_dashactive['serialnum_device'];?></td>
                      <td><?php echo $row_dashactive['device_location'];?></td>
                      <td style="color: red;" id="kelasiot/<?php echo $row_dashactive['serialnum_device']?>/Status">Offline</td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- chart -->
          <div class="col-6 ">
            <div class="card card-purple">
              <div class="card-header">
                <h3 class="card-title">Sensor Data Chart</h3>
              </div>
              <!-- chart -->
              <div class="card-body table-responsive p-0" style="height: 300px;">
                <canvas id="chartdash" style="width: 100% !important; height: 100% !important;"></canvas>
              </div>
            </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<!-- dibawah itu pengatruan javascriptnya untuk mqtt -->
<script src="https://unpkg.com/mqtt/dist/mqtt.min.js"></script>
<script>
  const webclientID = 'mqttjs_' + Math.random().toString(16).substr(2, 8);
  // const hostweb_emqx = 'wss://broker.emqx.io:8084/mqtt'
  const hostweb_private = "wss://prickleshift857.cloud.shiftr.io:443";
  const userbrokermqtt = "prickleshift857";
  const passbrokermqtt = "kelasiotcoba12";
  const option_konfigurasi = {
    keepalive: 60,
    clientId: webclientID,
    username: userbrokermqtt,
    password: passbrokermqtt,
    protocolId: "MQTT",
    protocolVersion: 4,
    clean: false,
    reconnectPeriod: 1000,
    connectTimeout: 60000
  };
  console.log("Menghubungkan ke Broker");
  const wsclient_connecttobroker = mqtt.connect(hostweb_private, option_konfigurasi);
  // const wsclient_connecttobroker = mqtt.connect(hostweb_private, option_konfigurasi);
  wsclient_connecttobroker.on('connect', () => {
    console.log('Terhubung ke Broker. ClientID: ' + webclientID);
    console.log('Broker: ' + hostweb_private);
    // console.log('Broker: ' + hostweb_private);

    let brokerStatus = document.getElementById("statusserverz");
    brokerStatus.innerHTML = "Online";
    brokerStatus.style.color = "green";
    console.log('Koneksi MQTT berhasil');
    wsclient_connecttobroker.subscribe("kelasiot/#", { qos: 1 }, function(err) {
        if (!err) {
            console.log('Subscribe ke topic kelasiot/# berhasil');
        } else {
            console.error('Gagal subscribe ke topic kelasiot/#', err);
        }
    });
  });
  //subscrie 
  wsclient_connecttobroker.on('message', function(topiczz, data_payloadz) {
    let topicku = topiczz.toString();
    let payloadku = data_payloadz.toString();
    console.log('Data diterima dari topic:', topicku, 'Payload:', payloadku);
    if (topicku == "kelasiot/ESP32-01/pot1") {
        document.getElementById("poten1").innerHTML = payloadku;
        console.log(payloadku);
    }
    else if (topicku == "kelasiot/ESP32-01/pot2") {
        document.getElementById("poten2").innerHTML = payloadku;
    }
    else if (topicku == "kelasiot/ESP32-01/ultras") {
        document.getElementById("ultras").innerHTML = payloadku;
    }
    //ini fungsi biar slidernya bisa mengingat kembali posis sebelumnya kalo kita misal kluar dari dashboard atau keluar dari web
    // maksudnya ini slider bisa update posisi terakhir kalau web sempet ditutup terus dibuka lagi
    // jadi kita subscribe lagi topic servo, terus karena itu retain, kita bisa nerima posisi terakhir slidernya
    else if(topicku == "kelasiot/ESP32-01/servoxxx"){
      let servo1postion = $("#servo1").data("ionRangeSlider");
      servo1postion.update({from: payloadku.toString()}); //fungsi bawaan ionredslider untuk javascript API
    }
    else if(topicku == "kelasiot/ESP32-01/srvvzz"){
      let servo2postion = $("#servo2").data("ionRangeSlider");
      servo2postion.update({from: payloadku.toString()}); //fungsi bawaan ionredslider untuk javascript API
    }
    // ini fungsi dibawah buat memori buttonled, atau retain led
    // led1
    else if(topicku == "kelasiot/ESP32-01/led1"){
      if(payloadku=="on"){
        document.getElementById("label-led1-on").classList.add("active");
        document.getElementById("label-led1-off").classList.remove("active");
      }else if(payloadku=="off"){
        document.getElementById("label-led1-on").classList.remove("active");
        document.getElementById("label-led1-off").classList.add("active");
      }
    }
    // led2
    else if(topicku == "kelasiot/ESP32-01/led2"){
      if(payloadku=="on"){
        document.getElementById("label-led2-on").classList.add("active");
        document.getElementById("label-led2-off").classList.remove("active");
      }else if(payloadku=="off"){
        document.getElementById("label-led2-on").classList.remove("active");
        document.getElementById("label-led2-off").classList.add("active");
      }
    }
    //fungsi untuk mendeteksi device online atau offline
    else if(topicku == "kelasiot/ESP32-01/Status"){
      let device_clientid = document.getElementById(topicku);
      device_clientid.innerHTML= payloadku;
      let payloadtrim = payloadku.trim();
      if(payloadtrim == "Online"){
        device_clientid.style.color = "green";
      } else if(payloadtrim == "Offline"){
        device_clientid.style.color = "red";
      }
    }
  });
  //publish
  function publishhdata(topicz,payloadz){
    wsclient_connecttobroker.publish(topicz, payloadz, {qos:1, retain:true});
  };
  function publish_servo(servoid,servotopic){
    let servo1value = document.getElementById(servoid).value;
    publishhdata(servotopic,servo1value);
  }
  // untuk jalanin function publish_servo bisa pakai atribut html onchange , gatau gmn caranya pakai addEventlistener, keknya ini grgr ini tuh slider bawaan adminLTE

  //function LED
  // kalau mau pakai atribut onchange pakai funsi publishlampu dibawah ini
  // function publishlampu(){
  //   if(document.getElementById('led2_ON').checked){
  //     payload_led = "on";
  //   }
  //   if(document.getElementById('led2_OFF').checked){
  //     payload_led = "off";
  //   }
  //   publishhdata("kelasiot/ESP32-01/led1",payload_led);
  // }
  //kita bisa pakai onchange di atribut htmlnya cuma lebih enak kyk dibawah ini
  // cara1
  // function publishled(){
  //   if(document.getElementById('led2_ON').checked){
  //     payload_led = "on";
  //   }
  //   if(document.getElementById('led2_OFF').checked){
  //     payload_led = "off";
  //   }
  //   publishhdata("kelasiot/ESP32-01/led1",payload_led);
  // }
  // document.getElementById("led2_ON").addEventListener("change", publishled);
  // document.getElementById("led2_OFF").addEventListener("change", publishled);

  // cara2
  function publishled(topic_led, idbuttonpub){
    if(document.getElementById(idbuttonpub+'_ON').checked){
      payload_led = "on";
    }
    if(document.getElementById(idbuttonpub+'_OFF').checked){
      payload_led = "off";
    }
    publishhdata(topic_led,payload_led);
  }
  function led_publishzzz(idbutton){
    document.getElementById(idbutton + "_ON").addEventListener("change", function(){publishled(("kelasiot/ESP32-01/" + idbutton), idbutton)});
    document.getElementById(idbutton + "_OFF").addEventListener("change", function(){publishled(("kelasiot/ESP32-01/" + idbutton), idbutton)});
  }
  led_publishzzz("led1");
  led_publishzzz("led2");
</script>
<script>
   // Ambil data dari PHP dan konversi menjadi format yang dapat digunakan di Chart.js
  const labels_datainTime_C = <?php echo $labels_datainTime_json; ?>;
  const data_ultrasC = <?php echo $dataUltras_json; ?>;
  const data_pot1C = <?php echo $dataPot1_json; ?>;
  const data_pot2C = <?php echo $dataPot2_json; ?>;

  new Chart("chartdash", {
    type: "line",
    data: {
      labels: labels_datainTime_C,
      datasets: [{
        label: "Ultras (red)",
        fill: false,
        lineTension: 0.5,
        backgroundColor: "rgba(0,0,255,1.0)",
        borderColor: "rgba(0,0,255,0.25)",
        data: data_ultrasC
      },
      {
        label: "Potentio 1 (blue)",
        fill: false,
        lineTension: 0.5,
        backgroundColor: "rgba(0,0,255,1.0)",
        borderColor: "rgba(128, 255, 0, 0.25)",
        data: data_pot1C
      },
      {
        label: "Potentio 2 (green)",
        fill: false,
        lineTension: 0.5,
        backgroundColor: "rgba(0,0,255,1.0)",
        borderColor: "rgba(255, 0, 0, 0.25)",
        data: data_pot2C
      },]
    },
    options: {
      // responsive: true,
      // maintainAspectRatio: false
      legend: {display: true},
      scales: {
        yAxes: [{ticks: {min: 6, max:50}}],
      }
    }
  });

</script>
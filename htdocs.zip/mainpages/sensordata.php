<?php
$sql_showsensorsdata =  "SELECT * FROM data_sensors"; //data_devices itu nama data total di database, bukan nama kolom,nanti kalo ada WHERE nya baru nama kolom
$result_sqlshowsensors = $db_connection->query($sql_showsensorsdata);
//mirip $result_sqlshowsensors = mysqli_query($db_connection, $sql_showsensorsdata);
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Sensor Data History</h1>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <!-- Main content -->
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        
        <!-- kalo lg- 6 div nya cuma setengah layar. kalo 12 dia full layar -->
        <!-- ultrasonic -->
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">UltraSonic</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Device Num</th>
                  <th>Data Value</th>
                  <th>Data Name</th>
                  <th>MQTT Topic</th>
                  <th>Time In</th>
                </tr>
                </thead>
                <tbody>
                  <?php while($row_ultras = $result_sqlshowsensors->fetch_assoc()){?>
                    <?php if($row_ultras["SensorType"] == "Ultras") { ?>
                    <tr>
                      <td><?php echo $row_ultras["serialnum_device"]; ?></td>
                      <td><?php echo $row_ultras["data_value"]; ?></td>
                      <td><?php echo $row_ultras["data_namez"]; ?></td>
                      <td> <?php echo $row_ultras["mqtt_topic_pot"]; ?></td>
                      <td><?php echo $row_ultras["DataIn_Time"]; ?></td>
                    </tr>
                  <?php } }?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
        <!-- pot1 -->
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Potentio 1</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="tablepot1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Device Num</th>
                    <th>Data Value</th>
                    <th>Data Name</th>
                    <th>MQTT Topic</th>
                    <th>Time In</th>
                  </tr>
                </thead>
                <tbody>
                  <?php mysqli_data_seek($result_sqlshowsensors, 0); // ini buat reset pointer while biar bisa muncul data poten disini, kalau ga diisi ntr ga muncul cuma ultras doang muncul // Reset pointer sebelum tabel Potentio 1 ?>
                  <?php while($row_ultras = $result_sqlshowsensors->fetch_assoc()){?>
                    <?php if($row_ultras["SensorType"] == "Poten1") { ?>
                    <tr>
                      <td><?php echo $row_ultras["serialnum_device"]; ?></td>
                      <td><?php echo $row_ultras["data_value"]; ?></td>
                      <td><?php echo $row_ultras["data_namez"]; ?></td>
                      <td> <?php echo $row_ultras["mqtt_topic_pot"]; ?></td>
                      <td><?php echo $row_ultras["DataIn_Time"]; ?></td>
                    </tr>
                  <?php } }?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
        <!-- pot2 -->
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Potentio 2</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="tablepot2" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Device Num</th>
                    <th>Data Value</th>
                    <th>Data Name</th>
                    <th>MQTT Topic</th>
                    <th>Time In</th>
                  </tr>
                </thead>
                <tbody>
                  <?php mysqli_data_seek($result_sqlshowsensors, 0); // Reset pointer sebelum tabel Potentio 2 ?>
                  <?php while($row_ultras = $result_sqlshowsensors->fetch_assoc()){?>
                    <?php if($row_ultras["SensorType"] == "Poten2") { ?>
                    <tr>
                      <td><?php echo $row_ultras["serialnum_device"]; ?></td>
                      <td><?php echo $row_ultras["data_value"]; ?></td>
                      <td><?php echo $row_ultras["data_namez"]; ?></td>
                      <td> <?php echo $row_ultras["mqtt_topic_pot"]; ?></td>
                      <td><?php echo $row_ultras["DataIn_Time"]; ?></td>
                    </tr>
                  <?php } }?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

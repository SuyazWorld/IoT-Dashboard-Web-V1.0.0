<?php
// disini ga perlu start session lagi, soalnya ini bukan page tersendiri
// kita pakai if session role dibawah ini, untuk mencegah user membuka menu user dengan ?page=userdata.php
if($_SESSION['role_sessionz'] != "Admin"){
  echo "<script>location.href='index.php'</script>"; //disini pakai javascript aja jangan php
}

$editcurretdevicepage = $_GET['page'];
$useralert_insertnotif = (int) 0;

//edit data
if(isset($_POST['userzedit_hidden'])){
  $old_uzernamez = $_POST['userzedit_hidden'];

  $usernamez_editzz = $_POST['usernamezz_edit'];
  $passz_editzz = $_POST['passwz_editz'];
  // $hash_passuserz_edit = hash("sha256", $passz_editzz);
  // PASSWORD_BCRYPT adalah salah satu algoritma hashing bawaan di PHP yang digunakan dalam fungsi
  $hash_passuserz_edit = password_hash($passz_editzz, PASSWORD_BCRYPT);
  $fullnamezz_editzz = $_POST['full_nameeditz'];
  $hakakses_editzz = $_POST['userroles_edit'];
  $conditionuser_editzz = $_POST['usercondition_editz'];
  
  $sqluser_editz = "UPDATE data_orang SET usernamezz = '$usernamez_editzz', passwordz2='$hash_passuserz_edit', fullname='$fullnamezz_editzz', peran='$hakakses_editzz', kondisi='$conditionuser_editzz' WHERE usernamezz='$old_uzernamez'";
  $resultsqluser_editz = $db_connection->query($sqluser_editz);
  if ($resultsqluser_editz) {
    $useralert_insertnotif = (int) 1;
  }else{
    $useralert_insertnotif = (int) 2;
  }
}
// tmbah data
elseif(isset($_POST['insernewuser_btnz'])){
  $userzname_new = $_POST['username_new'];
  $passwordz_new = $_POST['pass_new'];
  // $hash_passuserz_edit = hash("sha256", $passwordz_new);
  $hash_passuserz = password_hash($passwordz_new, PASSWORD_BCRYPT);
  $fullnamez_new = $_POST['fullname_new'];
  $hakaksesz_new = $_POST['hakakses_tambah'];

  $sqlnewinsert_userz = "INSERT INTO data_orang (usernamezz, passwordz2, fullname, peran) VALUES ('$userzname_new', '$hash_passuserz', '$fullnamez_new','$hakaksesz_new')";
  $resultsqlnewinsert_userz = $db_connection->query($sqlnewinsert_userz);
  if ($resultsqlnewinsert_userz) {
    $useralert_insertnotif = (int) 3;
  }else{
    $useralert_insertnotif = (int) 4;
  }
}
// menampilkan data di tabel edit data
if(isset($_GET['editbtn_userz'])){
  $usernameedit_get = $_GET['editbtn_userz'];
  $sql_editshowusrz = "SELECT * FROM data_orang WHERE usernamezz = '$usernameedit_get' LIMIT 1"; //sebelum edit data, kita buat dulu query select dulu untuk memilih data mana yang mau diedit
  // terus limit itu buat munculin satu data saja yang udah dipilihi, jadi jika udah nemu satu data , maka sql akan berhenti mencari lagi
  $result_editshowuserzz = $db_connection->query($sql_editshowusrz);
  $rowshow_usereditz = $result_editshowuserzz->fetch_assoc();
}


$sql_showuserdata =  "SELECT * FROM data_orang"; //data_devices itu nama data total di database, bukan nama kolom,nanti kalo ada WHERE nya baru nama kolom
$result_sqlshowuser = $db_connection->query($sql_showuserdata);
//mirip $result_sqlshowuser = mysqli_query($db_connection, $sql_showuserdata)
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">User</h1>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <!-- Main content -->
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <!-- TABEL -->
        <div class="col-lg-12">
          <?php
            if ($useralert_insertnotif == (int) 3) {alertinfoz("User berhasil ditambahkan....");}
            elseif ($useralert_insertnotif == (int) 4) {alertwarningz("User GAGAL ditambahkan....");}
            elseif ($useralert_insertnotif == (int) 1) {alertinfoz("User berhasil diEDIT....!!!");}
            elseif ($useralert_insertnotif == (int) 2) {alertwarningz("User GAGAL diEDIT....!!!");}
          ?>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">User List</h3>
            </div>
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Username</th>
                  <th>Fullname</th>
                  <th>Role</th>
                  <th>Condition</th>
                  <th>Edit Data</th>
                </tr>
                </thead>
                <tbody>
                  <?php while($row_userz = $result_sqlshowuser->fetch_assoc()){?>
                    <tr>
                      <td><?php echo $row_userz["usernamezz"]; ?></td>
                      <td><?php echo $row_userz["fullname"]; ?></td>
                      <td><?php echo $row_userz["peran"]; ?></td>
                      <td> <?php echo $row_userz["kondisi"]; ?></td>
                      <td><a href="?page=<?php echo $editcurretdevicepage?>&editbtn_userz=<?php echo $row_userz['usernamezz']?>"><i class="fas fa-edit"></i></a></td>
                    </tr>
                  <?php }?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <!-- form tambah dan edit data -->
        <?php if(isset($_GET['editbtn_userz'])){?>
          <!-- form edit data -->
          <div class="col-md-12">
            <div class="card card-orange">
              <div class="card-header">
                <h3 class="card-title">Edit Data</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="?page=userdata" method="POST">
                <!-- action itu dikirim ke page yang ada php untuk mengatur insert datanya, kita kirim ke sini karena phpnya ada diatas -->
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Username</label>
                    <input type="hidden" name="userzedit_hidden" value="<?php echo $rowshow_usereditz['usernamezz']?>">
                    <input type="text" class="form-control" name="usernamezz_edit" value="<?php echo $rowshow_usereditz['usernamezz']?>" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" name="passwz_editz" id="exampleInputPassword1" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Fullname</label>
                    <input type="text" class="form-control" name="full_nameeditz" id="exampleInputPassword1" value="<?php echo $rowshow_usereditz['fullname'] ?>" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Role</label>
                    <select class="form-control" name="userroles_edit">
                      <?php if($rowshow_usereditz['peran']=="Admin"){ ?>
                        <option value="Admin">Admin</option>
                        <option value="User">User</option>
                      <?php } else{?>
                        <option value="User">User</option>
                        <option value="Admin">Admin</option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Status</label>
                    <select class="form-control" name="usercondition_editz">
                      <?php if($rowshow_usereditz['kondisi']=="Active"){ ?>
                        <option value="Active">Active</option>
                        <option value="Not-Active">Not-Active</option>
                      <?php } else{?>
                        <option value="Not-Active">Not-Active</option>
                        <option value="Active">Active</option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" name="editdevicebtn" class="btn btn-warning">Edit</button>
                </div>
              </form>
            </div>
          </div>
        <?php } else { ?>
          <!-- form tambah data-->
          <div class="col-md-12">
            <div class="card card-olive">
              <div class="card-header">
                <h3 class="card-title">New User</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="?page=userdata" method="POST">
                <!-- action itu dikirim ke page yang ada php untuk mengatur insert datanya, kita kirim ke sini karena phpnya ada diatas -->
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Username</label>
                    <!-- required itu atribut buat input, jadi kalo blm diisi udah dipencet tombol submit nanti pasti ada peringatan buat isi -->
                    <input type="text" class="form-control" name="username_new" placeholder="Input Username here, username must be different" required> 
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" name="pass_new" id="exampleInputPassword1" placeholder="Input Password here" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Fullname</label>
                    <input type="text" class="form-control" name="fullname_new" id="exampleInputPassword1" placeholder="Input Fullname Here" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Role</label>
                    <select class="form-control" name="hakakses_tambah">
                        <option value="Admin">Admin</option>
                        <option value="User">User</option>
                    </select>
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" name="insernewuser_btnz" class="btn btn-success">Add</button>
                </div>
              </form>
            </div>
          </div>
        <?php }?>
      </div>
    </div>
  </div>
</div>

<!-- NOTE video 131: -->
<!-- 1. setelah input card tables, jangan lupa input jquery atau javascript  di data.hml, lalu ditaruh dibagian paling bawah index.php, ditaruh stelah bootsrap 4 jangan lupa benerin lokasi foldernya -->
<!-- 2 setelah itu, jangan lupa input cssnya di data.hmtl, yaitu yang <!-- DataTables -> , nanti dipaste di header.php tepat dibawah  <!-- Font Awesome -> DAN JUGA JANGAN LUPA UBAH lokasinya-->
<!-- 3 terakhir copy yang javascript function di data.hml paling bawah, kalo table 1 itu idnya example 1 kalo table 2 idnya example 2, tapi disini kita pakai yang example2, nanti bisa dipaste di index.php, ditaruh paling bawah aja -->

<!-- VIDEO NOTE 132 -->
<!-- 1. include dulu database.php disini -->
<!-- 2. buat query dan printah untuk jalanin querynya -->
<!-- 3. pakai perulangan while untuk menampilkan data, makanya nanti elemen tr diatas kita masukin ke line php (nanti dijepit dua php) -->
 
<!-- note video 134, mirip dengan 133, tapi inget kasi ini ?page=userdata di href di mainsidebar.php   -->
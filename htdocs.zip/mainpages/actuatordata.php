<?php
$sql_showactuatordata =  "SELECT * FROM data_actuator"; //data_devices itu nama data total di database, bukan nama kolom,nanti kalo ada WHERE nya baru nama kolom
$result_sqlshowactuator = $db_connection->query($sql_showactuatordata);
//mirip $result_sqlshowactuator = mysqli_query($db_connection, $sql_showactuatordata)
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Actuator Data History</h1>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <!-- Main content -->
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        
        <!-- kalo lg- 6 div nya cuma setengah layar. kalo 12 dia full layar -->
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Controller Type</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Device Num</th>
                  <th>Actuator Servo</th>
                  <th>Data Value</th>
                  <th>Servo Num</th>
                  <th>MQTT Topics</th>
                </tr> 
                </thead>
                <tbody>
                  <?php while($row_actuator = $result_sqlshowactuator->fetch_assoc()){?>
                    <tr>
                    
                      <td><?php echo $row_actuator["serialnum_device"]; ?></td>
                      <td><?php echo $row_actuator["actuatortype"]; ?></td>
                      <td><?php echo $row_actuator["data_value"]; ?></td>
                      <td> <?php echo $row_actuator["data_name"]; ?></td>
                      <td><?php echo $row_actuator["mqtt_topics"]; ?></td>
                    </tr>
                  <?php }?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<!-- NOTE video 131: -->
<!-- 1. setelah input card tables, jangan lupa input jquery atau javascript  di data.hml, lalu ditaruh dibagian paling bawah index.php, ditaruh stelah bootsrap 4 jangan lupa benerin lokasi foldernya -->
<!-- 2 setelah itu, jangan lupa input cssnya di data.hmtl, yaitu yang <!-- DataTables -> , nanti dipaste di header.php tepat dibawah  <!-- Font Awesome -> DAN JUGA JANGAN LUPA UBAH lokasinya-->
<!-- 3 terakhir copy yang javascript function di data.hml paling bawah, kalo table 1 itu idnya example 1 kalo table 2 idnya example 2, tapi disini kita pakai yang example2, nanti bisa dipaste di index.php, ditaruh paling bawah aja -->

<!-- VIDEO NOTE 132 -->
<!-- 1. include dulu database.php disini -->
<!-- 2. buat query dan printah untuk jalanin querynya -->
<!-- 3. pakai perulangan while untuk menampilkan data, makanya nanti elemen tr diatas kita masukin ke line php (nanti dijepit dua php) -->
 
<!-- note video 134, mirip dengan 133, tapi inget kasi ini ?page=devicedata di href di mainsidebar.php   -->